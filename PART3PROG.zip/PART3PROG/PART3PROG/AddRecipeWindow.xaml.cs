﻿using System.Collections.Generic;
using System.Windows;

namespace PART3PROG
{
    public partial class AddRecipeWindow : Window
    {
        private List<Recipe> recipes;
        private List<Ingredient> ingredients;

        public AddRecipeWindow(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            ingredients = new List<Ingredient>();
        }

        private void AddIngredientsButton_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(IngredientCountTextBox.Text, out int ingredientCount))
            {
                IngredientsPanel.Children.Clear();
                IngredientsPanel.Visibility = Visibility.Visible;

                for (int i = 0; i < ingredientCount; i++)
                {
                    var ingredientControl = new IngredientControl();
                    IngredientsPanel.Children.Add(ingredientControl);
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number of ingredients.");
            }
        }

        private void SaveRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            var recipe = new Recipe
            {
                Name = RecipeNameTextBox.Text
            };

            foreach (var control in IngredientsPanel.Children)
            {
                if (control is IngredientControl ingredientControl)
                {
                    recipe.Ingredients.Add(ingredientControl.GetIngredient());
                }
            }

            recipes.Add(recipe);
            Close();
        }
    }
}