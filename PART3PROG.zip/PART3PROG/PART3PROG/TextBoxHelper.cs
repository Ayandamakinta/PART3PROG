﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace RecipeManagerWPF.Helpers
{
    public static class TextBoxHelper
    {
        public static readonly DependencyProperty PlaceholderProperty =
            DependencyProperty.RegisterAttached(
                "Placeholder",
                typeof(string),
                typeof(TextBoxHelper),
                new PropertyMetadata(string.Empty, OnPlaceholderChanged));

        public static string GetPlaceholder(DependencyObject obj)
        {
            return (string)obj.GetValue(PlaceholderProperty);
        }

        public static void SetPlaceholder(DependencyObject obj, string value)
        {
            obj.SetValue(PlaceholderProperty, value);
        }

        private static void OnPlaceholderChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is TextBox textBox)
            {
                if (e.NewValue is string newPlaceholder)
                {
                    textBox.Loaded += (sender, args) => ShowPlaceholder(textBox, newPlaceholder);
                    textBox.GotFocus += (sender, args) => HidePlaceholder(textBox, newPlaceholder);
                    textBox.LostFocus += (sender, args) => ShowPlaceholder(textBox, newPlaceholder);
                }
            }
        }

        private static void ShowPlaceholder(TextBox textBox, string placeholder)
        {
            if (string.IsNullOrEmpty(textBox.Text))
            {
                textBox.Foreground = new SolidColorBrush(Colors.Gray);
                textBox.Text = placeholder;
            }
        }

        private static void HidePlaceholder(TextBox textBox, string placeholder)
        {
            if (textBox.Text == placeholder)
            {
                textBox.Text = string.Empty;
                textBox.Foreground = new SolidColorBrush(Colors.Black);
            }
        }
    }
}