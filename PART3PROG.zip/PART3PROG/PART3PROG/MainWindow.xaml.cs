﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PART3PROG
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadFoodGroups();
            LoadRecipes();
        }

        private void LoadFoodGroups()
        {
            // Load food groups into the ComboBox
            FoodGroupComboBox.ItemsSource = Enum.GetValues(typeof(FoodGroup));
        }

        private void LoadRecipes()
        {
            // Load recipes into the _allRecipes list
        }

        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            var ingredient = IngredientTextBox.Text.ToLower();
            var selectedFoodGroup = (FoodGroup)FoodGroupComboBox.SelectedItem;
            var maxCalories = CaloriesSlider.Value;

            var filteredRecipes = _allRecipes.Where(r =>
                r.Ingredients.Any(i => i.Name.ToLower().Contains(ingredient)) &&
                r.FoodGroup == selectedFoodGroup &&
                r.Calories <= maxCalories).ToList();

            RecipesListBox.ItemsSource = filteredRecipes;
        }

        private void AddToMenuButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedRecipe = (Recipe)RecipesListBox.SelectedItem;
            if (selectedRecipe != null)
            {
                MenuListBox.Items.Add(selectedRecipe);
            }
        }

        private void GeneratePieChartButton_Click(object sender, RoutedEventArgs e)
        {
            var menuRecipes = MenuListBox.Items.Cast<Recipe>().ToList();
            var foodGroupCounts = menuRecipes.GroupBy(r => r.FoodGroup)
                                             .Select(g => new { FoodGroup = g.Key, Count = g.Count() })
                                             .ToList();

            // Generate the pie chart
            FoodGroupChart.DataContext = foodGroupCounts;
        }
    }
}
